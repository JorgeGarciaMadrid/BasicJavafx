package aplicacion;

import javafx.scene.effect.GaussianBlur;
import javafx.scene.image.ImageView;

class Penguin {
	 	
	
		private ImageView forestview;

		
		public void initialize() {
			forestview.setEffect(new GaussianBlur(10));
		}	
}
